
package practica;
public class Practica {

    public static void main(String[] args) {
        System.out.println("========================================");  
        System.out.println("proyecto: informacion de la persona  "); 
        System.out.println("ejemplo:"); 
        System.out.println("alejandro arias "); 
        System.out.println("tengo 15 "); 
        System.out.println("========================================= "); 
        
       
        
    }
    
}
